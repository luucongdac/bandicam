MouseRecorder Portable Edition - Installation
---------------------------------------------

Bitte kopieren Sie zur Verwendung von MouseRecorder 
den Inhalt dieser Archivdatei in ein beliebiges 
Verzeichnis auf Ihrem USB Speicherstick.

Sie k�nnen das Programm von dort starten.

--

Please copy all files of this ZIP archive into any
directory on your USB memory device and launch the
program from there.

Manual: http://manual.mouserecorder.com

� 2014-2015 Bartels Media GmbH